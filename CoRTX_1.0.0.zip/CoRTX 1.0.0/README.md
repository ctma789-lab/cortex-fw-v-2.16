# CoRTX 1.0.0 — FS-i6 Transmitter Firmware

**FlySky FS-i6 firmware for the Dual-Cortex avoidance system.**

Built as a minimal, verified delta on top of the proven
**FlyPlus 1.7.6 SWE (ch7 failsafe)** base — the same known-good image
already running on the transmitter. CoRTX adds the avoidance telemetry
labels and CoRTX branding, and nothing else.

---

## Why this is built on FlyPlus, not the old CoreTX build

The earlier **CoreTX 1.0.0** image bricked the transmitter (flash
configuration field corrupted during flashing). This CoRTX 1.0.0 image
does **not** reuse that build. Instead it starts from your working
FlyPlus base and changes only what CoRTX needs:

- Boot vectors, flash config field (FCF) and the ch7 failsafe patch are
  **byte-identical** to the FlyPlus image already on the TX.
- Only the telemetry labels, the branding strings, and the CRC differ.

So if FlyPlus flashed and booted cleanly, this image will too. Flash it
the same way.

---

## What CoRTX 1.0.0 changes vs the FlyPlus base

40 bytes, in three places only — no code, vector table, or FCF touched:

| Change | Detail |
|---|---|
| Telemetry labels | 4 labels rewritten: **Zone, Obs., Flor, Alt.** (Head and RoC were already correct in the base) |
| Home-screen branding | Reads **CoRTX 1.0.0** / **CoRTX FW:** |
| Checksum | CRC-16/CCITT-FALSE recomputed = **0xA4EE** so the updater accepts the image |

The six labels match `comm_cortex_v2_1_8`'s `TELEM_TYPE` map exactly, so
the avoidance slots display with the right names with no firmware change
on the cortex side.

---

## Telemetry slots (as sent by comm_cortex v2.1.8)

| RX type_id | LCD label | Meaning |
|---|---|---|
| 0x01 | Zone | avoidance zone (0–3) |
| 0x02 | Obs. | closest obstacle (cm) |
| 0x08 | Head | threat bearing (deg) |
| 0x09 | RoC  | vertical velocity (cm/s) |
| 0x06 | Flor | floor height (cm) |
| 0x0F | Alt. | altitude AGL (cm) |

Native receiver battery telemetry (IntV / ExtV) is left untouched.

---

## Failsafe

`System → Failsafe` exposes **channels 1–7** (inherited from the FlyPlus
ch7 patch). Channel 7 is selectable for failsafe. This region is
byte-identical to the FlyPlus base.

---

## NOT included (deliberately)

This image does **not** carry the old CoreTX extras:

- 14-channel SBUS output extension
- PPM 4 / PPM 5 selectable aux sources
- ch4–ch9 failsafe range

Those came from the unverified CoreTX build that was associated with the
brick, including an appended code blob that cannot be validated by
inspection. If you need any of them, they should be re-derived and
bench-tested on the FlyPlus base as a separate, deliberate step — not
imported blind. Ask and we can build a verified channel-extension as a
follow-up (menu gates only, no unverified appended code).

---

## Files

| File | Purpose |
|---|---|
| `CoRTX_1.0.0.bin` | Firmware — **flash this** |
| `flysky-updater-linux64` | Linux flash tool |
| `flysky-updater-win64.exe` | Windows flash tool |

---

## Flashing

Same clean procedure you used for FlyPlus:

1. Power **off** the transmitter
2. Hold **OK** and power on — the update screen appears
3. Connect USB
4. Run:

```
# Linux
chmod +x flysky-updater-linux64
./flysky-updater-linux64 CoRTX_1.0.0.bin

# Windows
flysky-updater-win64.exe CoRTX_1.0.0.bin
```

Let the flash complete without interrupting it. Do not power off mid-write.

---

## Verify before flight

- On the bench, confirm the six telemetry slots populate. This depends on
  the receiver actually driving iBUS telemetry — confirm the X6B emits
  sensor polls first (see the iBUS sniffer test), or use an iA6B/iA10B.
- Test ch7 failsafe behaviour on the bench with props off.
- The operator is responsible for safe operation of any equipment using
  this firmware.

---

## Build provenance

- Base image: `fs-i6-swe_ch7_patched.bin` (FlyPlus 1.7.6 SWE, ch7 patch)
- Delta: 4 label edits @ 0x0DCD/0x0DD2/0x0DE6/0x0E13, branding @ 0x0D69B/0x0D6AD
- CRC-16/CCITT-FALSE (poly 0x1021, init 0xFFFF, LE) over bytes [0 : len-2]
- Audit: size, boot vector, FCF, CRC, ch7 gate, label map, branding, and
  change-scope all verified — no code/FCF/vector bytes altered.

*CoRTX — FS-i6 firmware · Version 1.0.0*
